class mapInfo {
	#include "Antistasi_Altis.Altis\mapInfo.hpp"
	#include "Antistasi_Other_Altis.Altis\mapInfo.hpp"
	#include "Antistasi_OPTRE_Madrigal.OPTRE_Madrigal\mapInfo.hpp"
	#include "Antistasi_abramia.abramia\mapInfo.hpp"
	#include "Antistasi_vt7.vt7\mission.sqm"
	#include "Antistasi_sara.sara\mapInfo.hpp"
};